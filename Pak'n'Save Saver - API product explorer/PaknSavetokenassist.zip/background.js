// Background service worker for the extension
console.log('Pak\'nSave Token Helper background script loaded');

// Store for captured tokens
let capturedTokens = {};

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request.action);
  
  if (request.action === 'captureToken') {
    captureToken();
    sendResponse({ success: true });
    return true;
  } else if (request.action === 'clearToken') {
    capturedTokens = {};
    chrome.storage.local.remove(['capturedToken']);
    sendResponse({ success: true });
    return true;
  } else if (request.action === 'tokenCaptured') {
    // Store token
    capturedTokens[request.storeId] = request.token;
    chrome.storage.local.set({ capturedToken: request.token });
    console.log('Token captured and saved:', request.token.substring(0, 20) + '...');
    
    // Send to popup if open
    sendTokenToPopup(request.token);
    
    // Send to Product Explorer
    sendTokenToExplorer(request.token);
    
    sendResponse({ success: true });
    return true;
  } else if (request.action === 'getToken') {
    // Return the captured token
    chrome.storage.local.get(['capturedToken'], (result) => {
      sendResponse({ token: result.capturedToken });
    });
    return true;
  }
  
  sendResponse({ success: false });
  return true;
});

function sendTokenToPopup(token) {
  console.log('Sending token to popup...');
  
  // Try to send to popup directly
  try {
    chrome.runtime.sendMessage({
      action: 'tokenCaptured',
      token: token,
      timestamp: new Date().toISOString()
    }).then(() => {
      console.log('Token sent to popup');
    }).catch(err => {
      console.log('Popup not open or not listening:', err.message);
    });
  } catch (error) {
    console.log('Could not send to popup:', error.message);
  }
}

async function captureToken() {
  console.log('Starting token capture process...');
  
  try {
    const result = await chrome.storage.local.get(['currentStore']);
    const storeId = result.currentStore?.id || '3c5e3145-0767-4066-9349-6c0a1313acc5';
    const storeName = result.currentStore?.name || 'PAK\'nSAVE Kaitaia';
    
    console.log(`Using store: ${storeName} (${storeId})`);
    
    const storeUrl = `https://www.paknsave.co.nz/shop/search?pg=1&q=`;
    console.log(`Opening store URL: ${storeUrl}`);
    
    // Create tab and inject monitoring
    const tab = await chrome.tabs.create({ 
      url: storeUrl, 
      active: true 
    });
    
    console.log(`Tab created with ID: ${tab.id}`);
    
    // Monitor network requests from this tab
    setupNetworkMonitoring(tab.id);
    
    // Also inject content script to monitor fetch/XHR
    setTimeout(async () => {
      try {
        console.log('Injecting content script...');
        
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['injector.js']
        });
        
        console.log('Content script injected successfully');
      } catch (injectError) {
        console.error('Failed to inject script:', injectError);
      }
    }, 2000);
    
  } catch (error) {
    console.error('Error in captureToken:', error);
  }
}

function setupNetworkMonitoring(tabId) {
  console.log(`Setting up network monitoring for tab ${tabId}`);
  
  const filter = { 
    urls: ["https://api-prod.paknsave.co.nz/*"], 
    tabId: tabId 
  };
  
  const extraInfoSpec = ["requestHeaders"];
  
  const listener = function(details) {
    // Check for authorization header
    if (details.requestHeaders) {
      for (let header of details.requestHeaders) {
        if (header.name.toLowerCase() === 'authorization' && header.value.startsWith('Bearer ')) {
          const token = header.value.replace('Bearer ', '');
          
          if (token && token.length > 10) {
            console.log('Token captured from network request');
            
            // Get store ID from URL if possible
            const storeMatch = details.url.match(/store\/([a-f0-9-]+)/);
            const storeId = storeMatch ? storeMatch[1] : 'unknown';
            
            // Send to background
            chrome.runtime.sendMessage({
              action: 'tokenCaptured',
              token: token,
              storeId: storeId,
              source: 'network'
            });
          }
          break;
        }
      }
    }
  };
  
  chrome.webRequest.onBeforeSendHeaders.addListener(listener, filter, extraInfoSpec);
  
  // Clean up after 30 seconds
  setTimeout(() => {
    chrome.webRequest.onBeforeSendHeaders.removeListener(listener);
    console.log('Network monitoring stopped for tab', tabId);
  }, 30000);
}

function sendTokenToExplorer(token) {
  console.log('Sending token to Product Explorer...');
  
  chrome.tabs.query({}, (tabs) => {
    for (let tab of tabs) {
      if (tab.url && tab.url.includes('paknsave_product_explorer_v12_proxycooldown.html')) {
        console.log('Found Product Explorer tab:', tab.id);
        
        chrome.tabs.sendMessage(tab.id, {
          action: 'updateToken',
          token: token
        }).then(() => {
          console.log('Token sent to Product Explorer');
        }).catch(err => {
          console.log('Product Explorer not ready, will retry...');
          
          // Retry after delay
          setTimeout(() => {
            chrome.tabs.sendMessage(tab.id, {
              action: 'updateToken',
              token: token
            }).catch(e => console.log('Retry failed'));
          }, 1000);
        });
      }
    }
  });
}

// Initialize
console.log('Pak\'nSave Token Helper initialized');