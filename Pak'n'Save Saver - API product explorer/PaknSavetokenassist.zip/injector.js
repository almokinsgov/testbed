// Content script injected into Pak'nSave pages
console.log('Pak\'nSave Token Capturer injected');

// Track if we've already captured a token
let tokenCaptured = false;

// Function to send token to extension
function sendTokenToExtension(token, source) {
  if (tokenCaptured) return; // Don't send multiple times
  
  tokenCaptured = true;
  console.log(`Sending token from ${source}:`, token.substring(0, 20) + '...');
  
  // Extract store ID from URL
  const storeMatch = window.location.pathname.match(/store\/([a-f0-9-]+)/);
  const storeId = storeMatch ? storeMatch[1] : 'unknown';
  
  // Send to extension
  chrome.runtime.sendMessage({
    action: 'tokenCaptured',
    token: token,
    storeId: storeId,
    source: source
  }).then(response => {
    console.log('Token sent successfully');
  }).catch(err => {
    console.log('Failed to send token:', err.message);
  });
}

// Monkey-patch fetch to capture tokens
const originalFetch = window.fetch;
window.fetch = function(...args) {
  return originalFetch.apply(this, args).then(response => {
    // Clone response to check headers
    const cloned = response.clone();
    
    // Check for authorization header
    const authHeader = cloned.headers.get('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.replace('Bearer ', '');
      sendTokenToExtension(token, 'fetch');
    }
    
    return response;
  });
};

// Monkey-patch XMLHttpRequest
const originalOpen = XMLHttpRequest.prototype.open;
const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;

XMLHttpRequest.prototype.open = function(method, url) {
  this._url = url;
  return originalOpen.apply(this, arguments);
};

XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
  if (header.toLowerCase() === 'authorization' && value.startsWith('Bearer ')) {
    const token = value.replace('Bearer ', '');
    sendTokenToExtension(token, 'xhr');
  }
  
  return originalSetRequestHeader.apply(this, arguments);
};

// Try to trigger API requests automatically
setTimeout(() => {
  console.log('Attempting to trigger API requests...');
  
  // Method 1: Click on first category link
  const categoryLinks = document.querySelectorAll('a[href*="category"], a[href*="Category"]');
  if (categoryLinks.length > 0) {
    console.log('Found category links, clicking first one');
    categoryLinks[0].click();
  }
  
  // Method 2: Look for any product tiles and hover over them
  setTimeout(() => {
    const productElements = document.querySelectorAll('[data-testid*="product"], [class*="product"], .product-tile');
    if (productElements.length > 0) {
      console.log('Found product elements, simulating interactions');
      
      // Hover over first product
      productElements[0].dispatchEvent(new MouseEvent('mouseover', {
        bubbles: true,
        cancelable: true
      }));
      
      // Click on it after a delay
      setTimeout(() => {
        productElements[0].click();
      }, 1000);
    }
  }, 1500);
}, 3000);

// Also monitor the page for any sign of API calls
setInterval(() => {
  // This is a fallback to check console for any tokens
  // (some sites might log them in development)
}, 5000);

console.log('Token capture script loaded and monitoring for API calls');