document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup loaded');
  
  // Load stored store info and token
  chrome.storage.local.get(['currentStore', 'capturedToken'], function(result) {
    if (result.currentStore) {
      document.getElementById('storeName').textContent = result.currentStore.name;
      document.getElementById('storeId').textContent = `ID: ${result.currentStore.id}`;
    }
    
    if (result.capturedToken) {
      displayToken(result.capturedToken);
    }
  });

  document.getElementById('openExplorer').addEventListener('click', function() {
    updateStatus('Opening Product Explorer...');
    chrome.tabs.query({}, function(tabs) {
      let explorerTab = null;
      for (let tab of tabs) {
        if (tab.url && tab.url.includes('paknsave_product_explorer_v12_proxycooldown.html')) {
          explorerTab = tab;
          break;
        }
      }
      
      if (explorerTab) {
        chrome.tabs.update(explorerTab.id, { active: true });
        updateStatus('Switched to existing Product Explorer');
      } else {
        chrome.tabs.create({ 
          url: 'paknsave_product_explorer_v12_proxycooldown.html',
          active: true 
        });
        updateStatus('Created new Product Explorer tab');
      }
    });
  });

  document.getElementById('captureToken').addEventListener('click', function() {
    console.log('Capture Token button clicked');
    updateStatus('Starting token capture...');
    
    chrome.runtime.sendMessage({ action: 'captureToken' }, function(response) {
      if (chrome.runtime.lastError) {
        console.error('Error:', chrome.runtime.lastError);
        updateStatus('Error: ' + chrome.runtime.lastError.message);
      } else if (response && response.success) {
        updateStatus('Opening Pak\'nSave website...');
        
        setTimeout(() => {
          updateStatus('Waiting for page to load...');
        }, 2000);
        
        setTimeout(() => {
          updateStatus('Monitoring network requests...');
        }, 4000);
      }
    });
  });

  document.getElementById('clearToken').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'clearToken' }, function(response) {
      updateStatus('Token cleared from storage.');
      hideTokenDisplay();
      
      // Also clear from page
      chrome.tabs.query({}, function(tabs) {
        for (let tab of tabs) {
          if (tab.url && tab.url.includes('paknsave_product_explorer_v12_proxycooldown.html')) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'clearToken'
            });
          }
        }
      });
    });
  });

  document.getElementById('openKaitaia').addEventListener('click', function() {
    const storeId = '3c5e3145-0767-4066-9349-6c0a1313acc5';
    const storeName = 'PAK\'nSAVE Kaitaia';
    
    updateStatus(`Setting store to ${storeName}...`);
    
    chrome.storage.local.set({
      currentStore: { id: storeId, name: storeName }
    }, function() {
      document.getElementById('storeName').textContent = storeName;
      document.getElementById('storeId').textContent = `ID: ${storeId}`;
      
      chrome.tabs.create({ 
        url: `https://www.paknsave.co.nz/shop/search?pg=1&q=`,
        active: true 
      });
      
      updateStatus(`Opened ${storeName}. Browse to capture token.`);
    });
  });

  // Copy token buttons
  document.getElementById('copyTokenSmall').addEventListener('click', copyTokenToClipboard);
  document.getElementById('copyToken').addEventListener('click', copyTokenToClipboard);
  
  function copyTokenToClipboard() {
    chrome.storage.local.get(['capturedToken'], function(result) {
      if (result.capturedToken) {
        navigator.clipboard.writeText(result.capturedToken).then(function() {
          updateStatus('✓ Token copied to clipboard!', true);
          
          // Show a temporary checkmark on the copy button
          const copyBtn = document.getElementById('copyTokenSmall');
          const originalText = copyBtn.textContent;
          copyBtn.textContent = '✓ Copied!';
          copyBtn.style.background = 'rgba(53,208,127,0.2)';
          copyBtn.style.color = '#35d07f';
          copyBtn.style.borderColor = 'rgba(53,208,127,0.4)';
          
          setTimeout(() => {
            copyBtn.textContent = originalText;
            copyBtn.style.background = 'rgba(255,195,92,0.1)';
            copyBtn.style.color = '#ffc35c';
            copyBtn.style.borderColor = 'rgba(255,195,92,0.3)';
          }, 2000);
          
        }).catch(function(err) {
          console.error('Failed to copy token: ', err);
          updateStatus('Failed to copy token to clipboard');
        });
      } else {
        updateStatus('No token to copy');
      }
    });
  }
  
  function displayToken(token) {
    const tokenDisplay = document.getElementById('tokenDisplay');
    const tokenValue = document.getElementById('tokenValue');
    const copyBtn = document.getElementById('copyToken');
    
    if (token && token.length > 10) {
      // Show truncated token for display
      const displayToken = token.length > 50 ? 
        token.substring(0, 30) + '...' + token.substring(token.length - 20) : 
        token;
      
      tokenValue.textContent = displayToken;
      tokenDisplay.style.display = 'block';
      copyBtn.classList.remove('hidden');
      
      // Store full token in a data attribute
      tokenDisplay.setAttribute('data-full-token', token);
    }
  }
  
  function hideTokenDisplay() {
    document.getElementById('tokenDisplay').style.display = 'none';
    document.getElementById('copyToken').classList.add('hidden');
    document.getElementById('tokenValue').textContent = '';
  }

  function updateStatus(message, isSuccess = false) {
    console.log('Status update:', message);
    const statusElement = document.getElementById('status');
    statusElement.textContent = message;
    
    if (isSuccess) {
      statusElement.style.color = '#35d07f';
      statusElement.style.background = 'rgba(53,208,127,0.1)';
    } else if (message.includes('Error')) {
      statusElement.style.color = '#ff5c5c';
      statusElement.style.background = 'rgba(255,92,92,0.1)';
    } else {
      statusElement.style.color = 'rgba(231,238,248,0.8)';
      statusElement.style.background = 'rgba(255,255,255,0.03)';
    }
    
    // Don't auto-clear success or error messages
    if (!isSuccess && !message.includes('Error') && !message.includes('Ready')) {
      setTimeout(() => {
        if (statusElement.textContent === message) {
          statusElement.textContent = 'Ready to capture tokens...';
          statusElement.style.color = 'rgba(231,238,248,0.8)';
          statusElement.style.background = 'rgba(255,255,255,0.03)';
        }
      }, 5000);
    }
  }

  // Listen for messages from background
  chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Popup received message:', request.action);
    
    if (request.action === 'tokenCaptured') {
      console.log('Token captured in popup');
      
      // Store the token
      chrome.storage.local.set({ capturedToken: request.token }, function() {
        // Display the token
        displayToken(request.token);
        
        // Update status
        updateStatus('✓ Token captured successfully!', true);
        
        // Auto-copy to clipboard if enabled in settings
        chrome.storage.local.get(['autoCopy'], function(result) {
          if (result.autoCopy) {
            copyTokenToClipboard();
          }
        });
      });
      
      sendResponse({ received: true });
      return true;
    }
  });
});