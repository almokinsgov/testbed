// Content script for the Product Explorer tool
console.log('Pak\'nSave Product Explorer content script loaded');

// Listen for token updates from extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Product Explorer received:', request.action);
  
  if (request.action === 'updateToken' && request.token) {
    console.log('Received token from extension');
    
    applyTokenToPage(request.token);
    sendResponse({ success: true });
    return true;
  } else if (request.action === 'clearToken') {
    clearTokenFromPage();
    sendResponse({ success: true });
    return true;
  }
  
  sendResponse({ success: false });
});

function applyTokenToPage(token) {
  // Update token field
  const tokenField = document.getElementById('authToken');
  if (tokenField) {
    tokenField.value = token;
    tokenField.type = 'text'; // Show token
    
    // Update token pill
    const tokenPill = document.getElementById('tokenPill');
    if (tokenPill) {
      tokenPill.textContent = '✓ Token Captured';
      tokenPill.style.background = 'rgba(53,208,127,0.2)';
      tokenPill.style.borderColor = 'rgba(53,208,127,0.4)';
    }
    
    // Set in sessionStorage if "Remember Token Session" is checked
    const rememberCheckbox = document.getElementById('rememberToken');
    if (rememberCheckbox && rememberCheckbox.checked) {
      sessionStorage.setItem('paknsave_token', token);
      sessionStorage.setItem('paknsave_token_expiry', 
        Date.now() + (5 * 60 * 1000));
    }
    
    // Also update TTL field to show when token expires
    const ttlField = document.getElementById('tokenTtlMin');
    if (ttlField) {
      ttlField.value = 5; // Reset to 5 minutes
    }
    
    showNotification('✓ Token successfully captured and applied!');
  }
}

function clearTokenFromPage() {
  const tokenField = document.getElementById('authToken');
  if (tokenField) {
    tokenField.value = '';
  }
  
  const tokenPill = document.getElementById('tokenPill');
  if (tokenPill) {
    tokenPill.textContent = 'Token Not Set';
    tokenPill.style.background = '';
    tokenPill.style.borderColor = '';
  }
}

function showNotification(message) {
  // Remove any existing notification
  const existing = document.querySelector('.token-notification');
  if (existing) existing.remove();
  
  // Create notification element
  const notification = document.createElement('div');
  notification.className = 'token-notification';
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: rgba(53,208,127,0.9);
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    z-index: 10000;
    font-size: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    animation: slideIn 0.3s ease-out;
  `;
  
  // Add CSS animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  // Remove after 3 seconds
  setTimeout(() => {
    notification.style.opacity = '0';
    notification.style.transition = 'opacity 0.3s';
    setTimeout(() => {
      notification.remove();
      style.remove();
    }, 300);
  }, 3000);
}

// Check if there's a stored token on page load
window.addEventListener('load', () => {
  setTimeout(() => {
    // Check extension storage first
    chrome.storage.local.get(['capturedToken'], (result) => {
      if (result.capturedToken) {
        console.log('Found stored token, applying...');
        applyTokenToPage(result.capturedToken);
      } else {
        // Check sessionStorage as fallback
        const storedToken = sessionStorage.getItem('paknsave_token');
        const expiry = sessionStorage.getItem('paknsave_token_expiry');
        
        if (storedToken && expiry && Date.now() < parseInt(expiry)) {
          applyTokenToPage(storedToken);
        }
      }
    });
  }, 1000);
});